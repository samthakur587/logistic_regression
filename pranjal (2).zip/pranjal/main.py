import os
import pandas as pd
import matplotlib.pyplot as plt
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI
from langchain.chains import ConversationalRetrievalChain
# Simple method - Split by pages 
loader = PyPDFLoader("2022_02_11_Montelogo_Ida (1).pdf")
pages = loader.load_and_split()
# SKIP TO STEP 2 IF YOU'RE USING THIS METHOD
chunks = pages
# Get embedding model

# Create vector database
db = FAISS.from_documents(chunks, embeddings)
db.save_local("faiss_index")
# qa = ConversationalRetrievalChain.from_llm(OpenAI(temperature=0.1), db.as_retriever())
# chat_history = []
# query = input('Enter your question .....  ')
# result = qa({"question": query, "chat_history": chat_history})
# chat_history.append((query, result['answer']))
print(type(db))