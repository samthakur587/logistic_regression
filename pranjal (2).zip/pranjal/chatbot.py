from fastapi import FastAPI,UploadFile, File
app = FastAPI()
import uvicorn
import requests
import os
import shutil
import pandas as pd
import matplotlib.pyplot as plt
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI
from langchain.chains import ConversationalRetrievalChain
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
embeddings = OpenAIEmbeddings(openai_api_key =OPENAI_API_KEY)
from fastapi.middleware.cors import CORSMiddleware
os.environ['OPENAI_API_KEY'] = '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'
origins = [
    "http://localhost",
    "http://localhost:3000",
    "http://localhost:8000",
    "http://localhost:8080",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
embeddings = OpenAIEmbeddings()
@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        with open('file.pdf','wb') as f:
            f.write(contents)
    except requests.exceptions.RequestException as err:
        return {"error": f"Error occurred during file upload: {str(err)}"}
    
    try:
        loader = PyPDFLoader("file.pdf")
        pages = loader.load_and_split()
        # SKIP TO STEP 2 IF YOU'RE USING THIS METHOD
        chunks = pages
        db = FAISS.from_documents(chunks, embeddings)
        db.save_local("faiss_index")
        os.remove("file.pdf")
        return {"filename": "file uploaded successfully"}
    except requests.exceptions.RequestException as err:
        return {"error": f"Error occurred during file processing: {str(err)}"}
@app.post("/askqA")
async def askqa(query: str = 'breif explain of this case'):
    chat_history = []
    try:
        new_db = FAISS.load_local("faiss_index", embeddings)
    except FileNotFoundError as file_err:
        return {'error': f"File not found First upload the docs: {str(file_err)}"}
    qa = ConversationalRetrievalChain.from_llm(OpenAI(temperature=0.1), new_db.as_retriever())
    
    try:
        result = qa({"question": query, "chat_history": chat_history})
        chat_history.append((query, result['answer']))
        return {'answer': result['answer']}
    except requests.exceptions.HTTPError as err:
        # Handle HTTP errors here
        return {'error': str(err)}
@app.get("/clearall")
async def clear():
    try:
        shutil.rmtree("faiss_index")
        return {'message':'all cache cleared'}
    except FileNotFoundError as file_err:
        return {'error': f"all the cache has already cleared : {str(file_err)}"}
    
    
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

