from langchain.llms import OpenAI
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferWindowMemory
from fastapi import FastAPI,UploadFile, File
app = FastAPI()
import uvicorn
import requests
import os
import shutil
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI
from langchain.chains import ConversationalRetrievalChain

# Create an instance of OpenAI language model
chat_history = []
os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
embeddings = OpenAIEmbeddings()
llm = OpenAI(temperature=0.4)
from fastapi.middleware.cors import CORSMiddleware

origins = [
    "http://localhost",
    "http://localhost:3000",
    "http://localhost:8000",
    "http://localhost:8080",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
embeddings = OpenAIEmbeddings()
@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        with open('file.pdf','wb') as f:
            f.write(contents)
    except requests.exceptions.RequestException as err:
        return {"error": f"Error occurred during file upload: {str(err)}"}
    
    try:
        loader = PyPDFLoader("file.pdf")
        pages = loader.load_and_split()
        # SKIP TO STEP 2 IF YOU'RE USING THIS METHOD
        chunks = pages
        db = FAISS.from_documents(chunks, embeddings)
        db.save_local("faiss_index")
        os.remove("file.pdf")
        return {"filename": "file uploaded successfully"}
    except requests.exceptions.RequestException as err:
        return {"error": f"Error occurred during file processing: {str(err)}"}
# Create an instance of ConversationChain with ConversationBufferWindowMemory
conversation_with_summary = ConversationChain(
    llm=llm,
    memory=ConversationBufferWindowMemory(k=2),
    verbose=True
)
memory = ConversationBufferMemory(memory_key='chat_history', return_messages=False)
# Define your API endpoint
@app.post("/askqA")
async def askqa(query: str = 'brief explanation of this case' ):
    global chat_history
    try:
        new_db = FAISS.load_local("faiss_index", embeddings)
    except FileNotFoundError as file_err:
        return {'error': f"File not found. First upload the docs: {str(file_err)}"}

    # Create an instance of ConversationalRetrievalChain with the OpenAI LLM and the retriever
    qa = ConversationalRetrievalChain.from_llm(llm, new_db.as_retriever())

    try:
        if len(chat_history) < 1:
            result = qa({"question": query, "chat_history": chat_history})
            #suggestions = ""
        else:
            result = qa({"question": query, "chat_history": chat_history})
            #suggestion_query = "Based on the previous chats, write 5 similar common questions based on this case."
            #suggestions = qa({"question": suggestion_query,"chat_history": chat_history})

        chat_history.append((query, result['answer']))
        return {'answer': result}#, 'suggestions': suggestions}
    except requests.exceptions.HTTPError as err:
        # Handle HTTP errors here
        return {'error': str(err)}